using UnityEngine;

public class RotationHandler : MonoBehaviour
{
    public void UpdateRotation(float input)
    {
        this.transform.Rotate(0, input, 0);
    }
}