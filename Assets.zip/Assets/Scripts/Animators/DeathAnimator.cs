using UnityEngine;

public class DeathAnimator : MonoBehaviour
{

    private Animator animator;

    public void Start()
    {
        this.animator = this.GetComponentInChildren<Animator>();
    }

    public void TriggerDeath()
    {
        this.animator.SetTrigger("death");
    }

}