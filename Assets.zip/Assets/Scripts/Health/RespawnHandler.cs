using UnityEngine;

[RequireComponent(typeof(DeathAnimator))]
public class RespawnHandler : MonoBehaviour
{
    public SwordHolder swordHolder;

    private DeathAnimator deathAnimator;

    private WalkHandler walkHandler;
    private RollHandler rollHandler;
    private JumpHandler jumpHandler;
    private CombatHandler combatHandler;

    public void Start()
    {
        this.deathAnimator = this.GetComponent<DeathAnimator>();

        this.walkHandler = this.GetComponent<WalkHandler>();
        this.rollHandler = this.GetComponent<RollHandler>();
        this.jumpHandler = this.GetComponent<JumpHandler>();
        this.combatHandler = this.GetComponent<CombatHandler>();
    }

    public void Respawn(Vector3 respawnPosition)
    {
        this.deathAnimator.TriggerDeath();
    }

    private void ResetPlayer()
    {
        this.walkHandler.DisableWalking();
        this.walkHandler.DisableSprinting();
        this.swordHolder.DisableSword();
        this.combatHandler.DisableAttacking();
        this.rollHandler.DisableRolling();
        this.jumpHandler.DisableJumping();
    }

}