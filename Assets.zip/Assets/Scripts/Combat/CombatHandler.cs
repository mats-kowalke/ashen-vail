using UnityEngine;

[RequireComponent(typeof(CombatAnimator))]
public class CombatHandler : MonoBehaviour
{
    public SwordHolder swordHolder;
    private bool isAttacking;
    private bool lastInward;
    private bool canAttack;
    private CombatAnimator combatAnimator;

    private WalkHandler walkHandler;
    private RollHandler rollHandler;
    private JumpHandler jumpHandler;


    public void Start()
    {
        this.isAttacking = false;
        this.canAttack = true;
        this.lastInward = Random.value < 0.5f;
        this.combatAnimator = this.GetComponent<CombatAnimator>();

        this.walkHandler = this.GetComponent<WalkHandler>();
        this.rollHandler = this.GetComponent<RollHandler>();
        this.jumpHandler = this.GetComponent<JumpHandler>();
    }

    public void DoAttack()
    {
        if (this.canAttack)
        {
            if (!isAttacking && this.swordHolder.holdsSword)
            {
                this.DisableOther();
                this.Invoke(nameof(EnableOther), 2.2f);
                this.isAttacking = true;
                this.lastInward = !lastInward;
                this.Invoke(nameof(ResetAttacking), 0.7f);
                this.combatAnimator.TriggerAttack(lastInward);
            }
        }
    }

    private void DisableOther()
    {
        if (this.walkHandler != null) this.walkHandler.DisableWalking();
        if (this.walkHandler != null) this.walkHandler.DisableSprinting();
        if (this.rollHandler != null) this.rollHandler.DisableRolling();
        if (this.jumpHandler != null) this.jumpHandler.DisableJumping();
    }

    private void EnableOther()
    {
        if (this.walkHandler != null) this.walkHandler.EnableWalking();
        if (this.walkHandler != null) this.walkHandler.EnableSprinting();
        if (this.rollHandler != null) this.rollHandler.EnableRolling();
        if (this.jumpHandler != null) this.jumpHandler.EnableJumping();
    }

    private void ResetAttacking()
    {
        this.isAttacking = false;
    }

    public void EnableAttacking()
    {
        this.canAttack = true;
    }

    public void DisableAttacking()
    {
        this.isAttacking = false;
        this.canAttack = false;
    }

}
